import pymongo
client=pymongo.MongoClient('mongodb://127.0.0.1:27017/')

db=client['Bank_Details']

information=db.info

import os
#print(os.getcwd())
os.chdir("C://Users/harsh/Desktop/bankingGui")
#print(os.getcwd())

#imports
from tkinter import *
import os
from PIL import ImageTk, Image

#Main Screen
master = Tk()
master.title('Banking Application')

#Functions

def finish_reg():
    name = temp_name.get()
    age = temp_age.get()
    gender = temp_gender.get()
    password = temp_password.get()
    
    if name =="" or age =="" or gender =="" or password =="" :
        notif.config(fg="red",text="*All fields are required* ")
        return

    for name_check in information.find({"Name":name}):
        notif.config(fg="red",text="Account already exists!")
        return
    else :
        information.insert_one({'Name' : name,'Age' : age, 'Gender' : gender, 'Password' : password, 'Balance' : '0'})
        notif.config(fg="green", text="Account has been created!")
        return
    
def register():
#vars
    global temp_name
    global temp_age
    global temp_gender
    global temp_password
    global notif
    temp_name    = StringVar()
    temp_age     = StringVar()
    temp_gender  = StringVar()
    temp_password= StringVar()

    # register screen
    register_screen = Toplevel(master)
    register_screen.title('Register')

    #Labels
    Label(register_screen, text ="Please enter details below to register.",fg="green" ,font=('Calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(register_screen, text ="Name:",font=('Calibri',12)).grid(row=1,sticky=W)
    Label(register_screen, text ="Age:",font=('Calibri',12)).grid(row=2,sticky=W)
    Label(register_screen, text ="Gender:",font=('Calibri',12)).grid(row=3,sticky=W)
    Label(register_screen, text ="Password:",font=('Calibri',12)).grid(row=4,sticky=W)
    notif = Label(register_screen,font=('Calibri',12))
    notif.grid(row=6,sticky=N,pady=10)
    
    #Entries
    Entry(register_screen, textvariable=temp_name).grid(row=1,column=0,sticky=E)
    Entry(register_screen, textvariable=temp_age).grid(row=2,column=0,sticky=E)
    Entry(register_screen, textvariable=temp_gender).grid(row=3,column=0,sticky=E)
    Entry(register_screen, textvariable=temp_password,show="*").grid(row=4,column=0,sticky=E)

    #Buttons
    Button(register_screen, text="Register", command=finish_reg, font=('Calibri',12)).grid(row=5,sticky=N,pady=10)

def login_session():
    global login_name
    login_name = temp_login_name.get()
    login_password = temp_login_password.get()

    if login_name =="" or login_password =="" :
        login_notif.config(fg="red",text="*All fields are required* ")
        return

    for account_check in information.find({"Name":login_name}):
        for password_check in information.find({"Password":login_password}):
            login_screen.destroy()
            account_dashboard = Toplevel(master)
            account_dashboard.title('Dashboard')
            #Labels
            Label(account_dashboard, text="Account Dashboard",font=('Calibri',12)).grid(row=0,sticky=N,pady=10)
            Label(account_dashboard, text="Welcome! " + login_name, fg="green",font=('Calibri',12)).grid(row=1,sticky=N,pady=5)
            #Buttons
            Button(account_dashboard, text="Personal Details",font=('Calibri',12),width=30,command=personal_details).grid(row=2,sticky=N,padx=10)
            Button(account_dashboard, text="Deposit",font=('Calibri',12),width=30,command=deposit).grid(row=3,sticky=N,padx=10)
            Button(account_dashboard, text="Withdraw",font=('Calibri',12),width=30,command=withdraw).grid(row=4,sticky=N,padx=10)
            Label(account_dashboard).grid(row=5,sticky=N,pady=10)
            return
        else :
            login_notif.config(fg="red", text="Password incorrect!!")
            return
    else :
        login_notif.config(fg="red", text="No account found !!")
        return

def deposit():
    #vars
    global amount
    global current_balance_label
    global deposit_notif
    amount = StringVar()

    #Deposit Screen
    deposit_screen = Toplevel(master)
    deposit_screen.title('Deposit')
    #Label
    Label(deposit_screen, text="Deposit Dashboard",fg="green" ,font=('Calibri',12)).grid(row=0,sticky=N,pady=10,padx=20)
    for b in information.find({"Name":login_name}):
        current_balance_label=Label(deposit_screen, text="Current Balance : $ " + str(b["Balance"]),font=('Calibri',12))
        current_balance_label.grid(row=1,sticky=W)
    Label(deposit_screen, text="Amount : ",font=('Calibri',12)).grid(row=2,sticky=W)
    deposit_notif = Label(deposit_screen,font=('Calibri',12))
    deposit_notif.grid(row=4,sticky=N,pady=5)
    #Entry
    Entry(deposit_screen, textvariable=amount).grid(row=2,column=1)
    #Button
    Button(deposit_screen,text="Finish",font=('Calibri',12),command=finish_deposit).grid(row=3,sticky=N,pady=5)
    
def finish_deposit():
    if amount.get()=="":
        deposit_notif.config(text='Amount is required!!',fg='red')
        return
    if float(amount.get())<=0:
        deposit_notif.config(text='Negative currency is not accepted!!',fg='red')
        return
    for c in information.find({"Name":login_name}):
        current_balance = c["Balance"]

    updated_balance = float(current_balance) + float(amount.get())
    information.update_one({"Name":login_name},{"$set":{"Balance":updated_balance}})
    
    for d in information.find({"Name":login_name}):
        current_balance_label.config(text="Current Balance : $ " + str(d["Balance"]),font=('Calibri',12))
       
    deposit_notif.config(text="Balance Updated!!",fg="green")

def withdraw():
    #vars
    global withdraw_amount
    global current_balance_label
    global withdraw_notif
    withdraw_amount = StringVar()

    #Withdraw Screen
    withdraw_screen = Toplevel(master)
    withdraw_screen.title('Withdraw')
    #Label
    Label(withdraw_screen, text="Withdraw Dashboard",fg="green",font=('Calibri',12)).grid(row=0,sticky=N,pady=10,padx=20)
    for b in information.find({"Name":login_name}):
         current_balance_label=Label(withdraw_screen, text="Current Balance : $ " + str(b["Balance"]),font=('Calibri',12))
         current_balance_label.grid(row=1,sticky=W)
    Label(withdraw_screen, text="Amount : ",font=('Calibri',12)).grid(row=2,sticky=W)
    withdraw_notif = Label(withdraw_screen,font=('Calibri',12))
    withdraw_notif.grid(row=4,sticky=N,pady=5)
    #Entry
    Entry(withdraw_screen, textvariable=withdraw_amount).grid(row=2,column=1)
    #Button
    Button(withdraw_screen,text="Finish",font=('Calibri',12),command=finish_withdraw).grid(row=3,sticky=N,pady=5)

def finish_withdraw():
    if withdraw_amount.get()=="":
        withdraw_notif.config(text='Amount is required!!',fg='red')
        return
    if float(withdraw_amount.get())<=0:
        withdraw_notif.config(text='Negative currency is not accepted!!',fg='red')
        return
    for c in information.find({"Name":login_name}):
        current_balance = c["Balance"]
    if float(withdraw_amount.get()) > float(current_balance):
        withdraw_notif.config(text="Insufficient Funds!!" ,fg='red')
        return
        
    updated_balance = float(current_balance) - float(withdraw_amount.get())
    information.update_one({"Name":login_name},{"$set":{"Balance":updated_balance}})

    for d in information.find({"Name":login_name}):
        current_balance_label.config(text="Current Balance : $ " + str(d["Balance"]),font=('Calibri',12))
    withdraw_notif.config(text="Balance Updated!!",fg="green")

def personal_details():
    #Personal details screen
    personal_details_screen = Toplevel(master)
    personal_details_screen.title('Personal Details')
    for a in information.find({"Name":login_name}): 
        #Labels
        Label(personal_details_screen, text="Personal Details Dashboard",fg="green",font=('Calibri',12)).grid(row=0,sticky=N,pady=10,padx=10)
        Label(personal_details_screen, text="Name: " + a["Name"],font=('Calibri',12)).grid(row=1,sticky=W)
        Label(personal_details_screen, text="Age: " + a["Age"],font=('Calibri',12)).grid(row=2,sticky=W)
        Label(personal_details_screen, text="Gender: " + a["Gender"],font=('Calibri',12)).grid(row=3,sticky=W)
        Label(personal_details_screen, text="Balance: $ " + str(a["Balance"]),font=('Calibri',12)).grid(row=4,sticky=W)
       
def login():
    #vars
    global temp_login_name
    global temp_login_password
    global login_notif
    global login_screen
    temp_login_name=StringVar()
    temp_login_password=StringVar()
    
    #Login screen
    login_screen = Toplevel(master)
    login_screen.title('Login')

    #Labels
    Label(login_screen, text="Login to your account.",fg="green",font=('Calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(login_screen, text="Username:",font=('Calibri',12)).grid(row=1,sticky=W)
    Label(login_screen, text="Password:",font=('Calibri',12)).grid(row=2,sticky=W)
    login_notif = Label(login_screen, font=('Calibri',12))
    login_notif.grid(row=4,sticky=N)

    #Entries
    Entry(login_screen,textvariable=temp_login_name).grid(row=1,column=1,padx=5)
    Entry(login_screen,textvariable=temp_login_password,show="*").grid(row=2,column=1,padx=5)

    #Buttons
    Button(login_screen, text="Login", command=login_session, width=15, font=('Calibri',12)).grid(row=3,sticky=N,pady=10)  
 
#Image import
img = Image.open('banklogo.png')
img = img.resize((150,150))
img = ImageTk.PhotoImage(img)

#Labels
Label(master, text ="Custom Banking Beta", font=('Calibri',14)).grid(row=0,sticky=N,pady=10)
Label(master, text ="The most secure bank you've probably used!",fg="green", font=('Calibri',12)).grid(row=1,sticky=N)
Label(master, image=img).grid(row=2,sticky=N,pady=15)

#Buttons
Button(master, text="Register",font=('Calibri',12),width=20,command=register).grid(row=3,sticky=N)
Button(master, text="Login",font=('Calibri',12),width=20,command=login).grid(row=4,sticky=N,pady=10)

master.mainloop()
